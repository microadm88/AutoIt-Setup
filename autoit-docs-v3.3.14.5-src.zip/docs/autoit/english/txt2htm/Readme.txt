Gen_txt2htm.au3 converts specially formatted text files to htm files which comprise the compiled help file.

The following is an example with explanations:

###Function### or ###Keyword### or ###User Defined Function###
Name goes here.

###Description###
One-line description (without HTML syntax)

###Syntax###
One-line syntax spec (without HTML syntax).

###Parameters###
Parameters naming:
The first letter signifies the expected type of the variable. This should be as follows: 
	$a<letter> - Array (the following letter describes the data type taken from the rest of the data types below,
		if it varies then v can be used.
	$d - Binary data.
	$h - Handle, usually to a file or window. NB: AutoIt handled controls return IDs, and so use $id instead.
	$id - An AutoIt control Id.
	$i - Integer.
	$b - Boolean.
	$f - Floating point number.
	$n - General number with no preference for floating point or integer.
	$s - String.
	$v - Variant (unknown/variable type of data).
	$o - COM object.
	$p - Pointer. It is assumed that it points to a struct so no further letters are needed.
		The type of struct being pointed to should be inferrable from the variable name e.g. $pWindowRect can be assumed to be a pointer to a $tagRECT structure.
	$t - Structure returned from DllStructCreate().
	$tag - Struct definition string. Structure definitions should conform to the structure guidelines.

This convention applies also to Local/Global variables. Global variables must have an extra first letter "g" e.g. g_sVar. UDF global variables must start with an underscore e.g. $__g_sVar.
Const/Enum variables are better if they are defined in UpperCase to illustrate that they cannot be changed. First letter of the constant is optional, $e can be used.
Note: Global variables should only be used if they are called from more than one function or used in another scope. For example if the variable is only used in main scope
regardless of not in a function, then it should be declared using Local.

@@ParamTable@@
Description
	ParamTables are special, two-column tables
	where the first column is only one line,
	but the second column can be many lines.
How To Denote
	Any information that appears in the second
	column must be indented with at least one tab.
	Each entry that is NOT indented begins a new row.
	DO NOT LEAVE ANY BLANK LINE BETWEEN HERE AND "@@End@"
@@End@@

###ReturnValue###
@@ReturnTable@@
Success:	@TAB followed by info for second column as 1.
; If several line are needed to describe they must start  with @TAB. More than one @TAB allows small extra indentation.
Failure:	@TAB followed by info for second column as 0.
@error:	@TAB followed by value explanation.
@@End@@

###Remarks###
In general, whitespace outside of tables is ignored.
@TAB are converted to 4 blanks which allow small identation.
IN the Remarks Section:  non-consecutive blank lines are converted as HTML <br />'s.

You can also use <strong>bold</strong> and <em>italic</em> tags.  Pretty much any HTML formatting can be used, since this text is more or less copied directly over to the HTM file.

Remarks go here.  Here's a standard table; each line is a new row, and columns are tab-separated:

@@StandardTable@@
row1col1	row1col2	row1col3	row1col4
row2col1	row2col2	row2col3	row2col4
@@End@@

###Related###
Foo, Bar (Option), <a href="whatever/baz.htm">Baz</a>

; the above will be converted to the following HTML:
<a href="foo.htm">Foo</a>, <a href="AutoItSetOption.htm#Bar">Bar (Option)</a>, <a href="whatever/baz.htm">Baz</a>

###See Also###
@@MsdnLink@@ stringToBeSearched

; A Link that will search on the Msdn Online library will be inserted.

###Example###
The example will be formatted appropriately
Indent the lines with tabs; they will be converted to spaces (4, I think) in the HTML output.

; or

@@IncludeExample@@ [NameOfDuplicateUDF]

; The example under \examples or \libExamples will be included.
; All examples should pass #AutoIt3Wrapper_Au3Check_Parameters=-q -d -w 1 -w 2 -w 3 -w- 4 -w 5 -w 6 -w- 7 without errors or warning.
; If the optional name is defined it will be the file NameOfDuplicateUDF.au3 will be used.
